vCrypter:

- Type the client version and the tool will calculate/return the correct UO login keys for any classic or enhanced client.

NOTE: In order for them to work with sphere you have to add them manually to your sphereCrypt.ini and enable client encryptions on Sphere.ini. You can copy/paste the result.